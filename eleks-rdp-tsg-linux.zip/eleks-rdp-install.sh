#!/usr/bin/env bash

# Install a beta version of FreeRDP that supports TSG Gateway connections.
# 
# Based on the official instructions at:
# https://github.com/FreeRDP/FreeRDP/wiki/Compilation
#

# Install prerequisite libs
sudo apt-get update
sudo apt-get install build-essential git-core cmake libssl-dev libx11-dev libxext-dev libxinerama-dev libxcursor-dev libxdamage-dev libxv-dev libxkbfile-dev libasound2-dev libcups2-dev libxml2 libxml2-dev libxrandr-dev libgstreamer0.10-dev libgstreamer-plugins-base0.10-dev libxi-dev libgstreamer-plugins-base1.0-dev libavutil-dev libavcodec-dev libcunit1-dev libdirectfb-dev libxtst-dev

# Clone the source code
git clone git://github.com/FreeRDP/FreeRDP.git FreeRDP

# Check out an older branch that actually works
# 1.2.0+ versions seem to have an issue with TSG authentication
cd FreeRDP
git checkout 1.1.0-beta+2013071101

# Generate Makefile
cmake -DCMAKE_BUILD_TYPE=Release -DWITH_SSE2=ON -DWITH_FFMPEG=OFF -DWITH_XINERAMA=OFF -DWITH_XCURSOR=OFF .

# Compile
make

# Install the binaries to the system
sudo make install

# Link the shared libraries
echo '/usr/local/lib/freerdp' | sudo tee /etc/ld.so.conf.d/freerdp.conf
sudo ldconfig
