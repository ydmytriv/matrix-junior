#!/usr/bin/env bash

GATEWAY=tsg.eleks.com
DOMAIN=eleks-software.local
RESOLUTION=1920x1080

if [ -z "$1" ]; then
    read -p "Computer name (e.g. CP1234): " COMPUTERNAME
else
    COMPUTERNAME=$1
fi

if [ -z "$2" ]; then
    read -p "ELEKS username (e.g. 'firstname.lastname'): " USERNAME
else
    USERNAME=$2
fi

if [ -z "$3" ]; then
    read -s -p "Password: " PASSWORD
else
    PASSWORD=$3
fi

echo
echo "Running FreeRDP..."
echo

xfreerdp /cert-ignore /sec:nla \
    /size:$RESOLUTION /bpp:24 /rfx +smartsizing +fonts +aero +clipboard +async-input +async-update -offscreen-cache -glyph-cache \
    /v:$COMPUTERNAME.$DOMAIN \
    /d:$DOMAIN \
    /u:$USERNAME@$DOMAIN \
    /p:$PASSWORD \
    /g:$GATEWAY \
    /gd:$DOMAIN \
    /gu:$USERNAME@$DOMAIN \
    /gp:$PASSWORD
